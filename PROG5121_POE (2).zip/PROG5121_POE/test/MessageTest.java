package prog5121poe;

import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {
    private final Message messageHandler = new Message();

    @Test
    public void testMessageIDCorrect() {
        assertTrue("Message ID should be valid (<= 10 chars)", messageHandler.checkMessageID("M123"));
    }

    @Test
    public void testMessageIDIncorrect() {
        assertFalse("Message ID should fail if > 10 chars", messageHandler.checkMessageID("ThisIDIsWayTooLong123"));
    }

    @Test
    public void testRecipientCellCorrect() {
        String result = messageHandler.checkRecipientCell("+271234567");
        assertEquals("Cell phone number successfully captured.", result);
    }

    @Test
    public void testRecipientCellIncorrect() {
        String result = messageHandler.checkRecipientCell("0821234567"); // Missing '+'
        assertTrue(result.contains("incorrectly formatted"));
    }

    @Test
    public void testCreateMessageHash() {
        String hash = messageHandler.createMessageHash("CH123", 1, "Python is awesome");
        assertEquals("CH:1:PYTHONAWESOME", hash);
    }
}