package prog5121poe;

import org.json.simple.JSONObject;
import java.io.FileWriter;
import java.io.IOException;

public class Message {
    private int totalMessagesSent = 0;
    private StringBuilder allMessagesLog = new StringBuilder();

    public boolean checkMessageID(String messageID) {
        if (messageID == null) return false;
        return messageID.length() <= 10;
    }

    public String checkRecipientCell(String cellNumber) {
        // Updated to <= 12 to accommodate international codes like +27...
        if (cellNumber != null && cellNumber.startsWith("+") && cellNumber.length() <= 12) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    public String createMessageHash(String messageID, int messageNum, String messageText) {
        if (messageID == null || messageID.length() < 2) {
            return "00:" + messageNum + ":ERROR";
        }
        String prefix = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0].toUpperCase() : "";
        String lastWord = words.length > 1 ? words[words.length - 1].toUpperCase() : firstWord;

        return prefix + ":" + messageNum + ":" + firstWord + lastWord;
    }

    public String printMessages() {
        return allMessagesLog.toString();
    }

    public int returnTotalMessagess() {
        return totalMessagesSent;
    }

    public void incrementTotalMessages() {
        this.totalMessagesSent++;
    }

    public void appendMessageLog(String logEntry) {
        this.allMessagesLog.append(logEntry);
    }

    @SuppressWarnings("unchecked")
    public void storeMessage(String id, String hash, String recipient, String message) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("messageID", id);
        jsonObject.put("messageHash", hash);
        jsonObject.put("recipient", recipient);
        jsonObject.put("message", message);

        try (FileWriter file = new FileWriter("messages.json", true)) {
            file.write(jsonObject.toJSONString() + "\n");
            System.out.println("Message successfully stored to JSON file.");
        } catch (IOException e) {
            System.out.println("Error writing to JSON file: " + e.getMessage());
        }
    }
}